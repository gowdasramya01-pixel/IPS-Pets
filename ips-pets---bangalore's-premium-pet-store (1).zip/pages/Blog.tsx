
import React from 'react';
import { motion } from 'framer-motion';
import { useCMS } from '../App';
import { Calendar, User, ChevronRight } from 'lucide-react';

const Blog: React.FC = () => {
  const { state } = useCMS();

  return (
    <div className="bg-slate-50 min-h-screen pb-24">
      <div className="bg-amber-500 py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-serif font-bold mb-4">Pet Care Tips</h1>
          <p className="text-amber-100 max-w-2xl mx-auto text-lg">Expert advice and articles to help you raise a happy and healthy companion.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {state.posts.map((post) => (
            <motion.div 
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all group"
            >
              <div className="aspect-video overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-8">
                <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                  <div className="flex items-center gap-1.5"><Calendar className="w-4 h-4" /> {post.date}</div>
                  <div className="flex items-center gap-1.5"><User className="w-4 h-4" /> By Admin</div>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4 group-hover:text-amber-500 transition-colors">{post.title}</h3>
                <p className="text-slate-600 mb-6 leading-relaxed line-clamp-3">{post.content}</p>
                <button className="flex items-center gap-2 text-amber-500 font-bold hover:gap-3 transition-all">
                  Read Article <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Blog;
