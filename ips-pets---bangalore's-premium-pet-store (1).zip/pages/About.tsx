
import React from 'react';
import { motion } from 'framer-motion';
import { useCMS } from '../App';
import { Award, ShieldCheck, Users, Clock } from 'lucide-react';

const About: React.FC = () => {
  const { state } = useCMS();

  return (
    <div className="pb-24">
      {/* Header */}
      <section className="bg-slate-900 py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-serif font-bold mb-6"
          >
            Our Story
          </motion.h1>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg leading-relaxed">
            Founded in the heart of Bangalore, IPS Pets has become a beacon of trust for pet lovers across the city.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1544568100-847a948585b9?auto=format&fit=crop&q=80&w=1000" 
              alt="Golden Retriever" 
              className="rounded-3xl shadow-2xl"
            />
          </div>
          <div>
            <h2 className="text-3xl font-serif font-bold text-slate-900 mb-8">Committed to Quality & Ethics</h2>
            <div className="space-y-6 text-slate-600 text-lg">
              <p>{state.content.aboutText}</p>
              <p>
                We believe that bringing a pet into your life is a major decision. That's why we don't just "sell" pets; 
                we ensure every match is made for the long term. Our facilities are maintained to the highest standards 
                of hygiene and our puppies are socialized from day one.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 mt-12">
              <div className="flex items-start gap-4">
                <div className="bg-amber-100 p-2 rounded-lg"><Award className="w-6 h-6 text-amber-600" /></div>
                <div><h4 className="font-bold">Premium Quality</h4><p className="text-sm text-slate-500">Only the best lineages</p></div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-amber-100 p-2 rounded-lg"><Users className="w-6 h-6 text-amber-600" /></div>
                <div><h4 className="font-bold">Happy Families</h4><p className="text-sm text-slate-500">1000+ pets adopted</p></div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-amber-100 p-2 rounded-lg"><ShieldCheck className="w-6 h-6 text-amber-600" /></div>
                <div><h4 className="font-bold">Verified Health</h4><p className="text-sm text-slate-500">Certificates included</p></div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-amber-100 p-2 rounded-lg"><Clock className="w-6 h-6 text-amber-600" /></div>
                <div><h4 className="font-bold">24/7 Support</h4><p className="text-sm text-slate-500">Expert guidance always</p></div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
