
import React from 'react';
import { motion } from 'framer-motion';
import { useCMS } from '../App';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  const { state } = useCMS();

  return (
    <div className="bg-white min-h-screen pb-24">
      <section className="bg-slate-50 py-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Star className="w-12 h-12 text-amber-500 mx-auto mb-6" />
          <h1 className="text-5xl font-serif font-bold text-slate-900 mb-4">Client Testimonials</h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg">Hear from our happy pet parents who found their new family members at IPS Pets.</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {state.testimonials.map((testimonial) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 relative group hover:-translate-y-2 transition-transform duration-300"
            >
              <Quote className="absolute top-6 right-6 w-12 h-12 text-slate-50" />
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-amber-500 fill-amber-500" />
                ))}
              </div>
              <p className="text-slate-600 italic mb-8 relative z-10 text-lg leading-relaxed">"{testimonial.text}"</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center font-bold text-slate-600">
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">{testimonial.name}</h4>
                  <p className="text-sm text-slate-500">Verified Buyer</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Testimonials;
