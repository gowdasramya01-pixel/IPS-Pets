
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useCMS } from '../App';
import { Search, Filter, PawPrint } from 'lucide-react';
import BreedCard from '../components/BreedCard';

const Breeds: React.FC = () => {
  const { state } = useCMS();
  const [search, setSearch] = useState('');

  const filteredBreeds = state.breeds.filter(breed => 
    breed.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <PawPrint className="text-amber-500 w-5 h-5" />
                <span className="text-slate-500 font-bold uppercase tracking-widest text-xs">Our Collection</span>
              </div>
              <h1 className="text-4xl font-serif font-bold text-slate-900">Available Breeds</h1>
              <p className="text-slate-500 mt-2">Explore {state.breeds.length} premium breeds currently available for adoption.</p>
            </div>
            
            <div className="relative max-w-md w-full">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-slate-400" />
              </div>
              <input
                type="text"
                placeholder="Search breeds (e.g. Labrador)..."
                className="block w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all text-slate-900"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {filteredBreeds.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredBreeds.map((breed, index) => (
              <motion.div
                key={breed.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <BreedCard breed={breed} />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-300">
            <Search className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-slate-900">No breeds found</h3>
            <p className="text-slate-500">Try adjusting your search query.</p>
          </div>
        )}
      </section>
    </div>
  );
};

export default Breeds;
