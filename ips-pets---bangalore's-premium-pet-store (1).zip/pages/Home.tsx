
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useCMS } from '../App';
import { ArrowRight, CheckCircle, ShieldCheck, Heart } from 'lucide-react';
import BreedCard from '../components/BreedCard';

const Home: React.FC = () => {
  const { state } = useCMS();

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center">
        <div className="absolute inset-0">
          <img 
            src={state.content.heroImage} 
            alt="Puppies Group" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/40 to-transparent" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <div className="flex items-center gap-2 mb-6">
              <span className="h-px w-8 bg-amber-500"></span>
              <span className="text-amber-500 font-bold uppercase tracking-widest text-sm">Welcome to IPS Pets</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-6 leading-tight">
              {state.content.heroTitle}
            </h1>
            <p className="text-xl text-slate-200 mb-10 leading-relaxed">
              {state.content.heroSubtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/breeds" className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-xl shadow-amber-500/20">
                View Breeds <ArrowRight className="w-5 h-5" />
              </Link>
              <Link to="/contact" className="bg-white/10 hover:bg-white/20 text-white backdrop-blur-md px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all">
                Contact Us
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Breeds */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div>
              <h2 className="text-4xl font-serif font-bold text-slate-900 mb-4">Popular Puppies</h2>
              <p className="text-slate-600 max-w-lg">Discover our most loved breeds, hand-raised with care and ready to bring joy to your home.</p>
            </div>
            <Link to="/breeds" className="text-amber-500 font-bold flex items-center gap-2 hover:translate-x-1 transition-transform">
              Explore All Breeds <ArrowRight className="w-5 h-5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {state.breeds.slice(0, 4).map((breed) => (
              <BreedCard key={breed.id} breed={breed} />
            ))}
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { icon: <ShieldCheck className="w-10 h-10 text-amber-500" />, title: 'Certified Health', desc: 'All puppies come with health certificates and first vaccinations.' },
              { icon: <CheckCircle className="w-10 h-10 text-amber-500" />, title: 'Pure Bred', desc: 'We specialize in high-quality, authentic pure-bred lineage only.' },
              { icon: <Heart className="w-10 h-10 text-amber-500" />, title: 'Lifetime Support', desc: 'Expert advice on pet care and nutrition even after adoption.' },
            ].map((feature, idx) => (
              <div key={idx} className="flex flex-col items-center text-center p-8 rounded-2xl bg-white shadow-sm hover:shadow-md transition-shadow">
                {feature.icon}
                <h3 className="text-xl font-bold mt-6 mb-3 text-slate-900">{feature.title}</h3>
                <p className="text-slate-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
