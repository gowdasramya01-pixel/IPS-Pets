
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useCMS } from '../App';
import { Phone, MessageCircle, MapPin, Send } from 'lucide-react';

const Contact: React.FC = () => {
  const { state } = useCMS();
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Info Side */}
          <div>
            <h1 className="text-5xl font-serif font-bold text-slate-900 mb-8">Get In Touch</h1>
            <p className="text-slate-600 text-lg mb-12">
              Have questions about a specific breed or want to schedule a visit? 
              Our team is here to help you find your perfect companion.
            </p>

            <div className="space-y-10">
              <a href={`tel:${state.content.contactPhone}`} className="flex items-start gap-6 group">
                <div className="bg-amber-500 p-4 rounded-2xl group-hover:scale-110 transition-transform">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-slate-500 font-bold uppercase tracking-widest text-xs mb-1">Call Us</h4>
                  <p className="text-2xl font-bold text-slate-900">{state.content.contactPhone}</p>
                </div>
              </a>

              <a href={`https://wa.me/91${state.content.contactPhone}`} target="_blank" rel="noreferrer" className="flex items-start gap-6 group">
                <div className="bg-green-500 p-4 rounded-2xl group-hover:scale-110 transition-transform">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-slate-500 font-bold uppercase tracking-widest text-xs mb-1">WhatsApp</h4>
                  <p className="text-2xl font-bold text-slate-900">Message for Inquiry</p>
                </div>
              </a>

              <div className="flex items-start gap-6">
                <div className="bg-slate-800 p-4 rounded-2xl">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-slate-500 font-bold uppercase tracking-widest text-xs mb-1">Visit Us</h4>
                  <p className="text-2xl font-bold text-slate-900">Bangalore, India</p>
                  <p className="text-slate-500">Karnataka, Pin: 560001</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="bg-slate-50 p-10 rounded-[2.5rem] border border-slate-100">
            {submitted ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }} 
                animate={{ opacity: 1, scale: 1 }}
                className="h-full flex flex-col items-center justify-center text-center py-20"
              >
                <div className="bg-green-100 p-4 rounded-full mb-6">
                  <Send className="w-12 h-12 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Message Sent!</h3>
                <p className="text-slate-500">We will call you back shortly on {phone}.</p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="mt-8 text-amber-500 font-bold"
                >
                  Send another message
                </button>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-900 mb-8">Send an Inquiry</h3>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Your Phone Number</label>
                  <input
                    required
                    type="tel"
                    placeholder="Enter your mobile number"
                    className="w-full px-6 py-4 rounded-2xl border-slate-200 focus:ring-2 focus:ring-amber-500 outline-none transition-all"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">What are you looking for?</label>
                  <textarea
                    required
                    rows={5}
                    placeholder="Tell us which breed you're interested in..."
                    className="w-full px-6 py-4 rounded-2xl border-slate-200 focus:ring-2 focus:ring-amber-500 outline-none transition-all resize-none"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-5 rounded-2xl shadow-xl shadow-amber-500/20 transition-all flex items-center justify-center gap-3"
                >
                  Submit Inquiry <Send className="w-5 h-5" />
                </button>
                <p className="text-xs text-slate-400 text-center italic">
                  By submitting, you agree to receive a call back from IPS Pets.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Google Maps Placeholder (Using a styled div for Bangalore Location) */}
      <section className="h-[450px] w-full bg-slate-200 relative grayscale hover:grayscale-0 transition-all duration-700">
        <div className="absolute inset-0 flex items-center justify-center">
           <div className="bg-white px-8 py-6 rounded-2xl shadow-2xl flex items-center gap-4">
              <div className="bg-amber-500 p-3 rounded-full"><MapPin className="text-white w-6 h-6" /></div>
              <div>
                <h4 className="font-bold text-slate-900">IPS Pets Bangalore</h4>
                <p className="text-sm text-slate-500">Premium Puppy Agency</p>
              </div>
           </div>
        </div>
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d124440.31500366628!2d77.5144131!3d12.9248238!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1670c9b44e6d%3A0xf8dfc3e8517e4fe0!2sBengaluru%2C%20Karnataka!5e0!3m2!1sen!2sin!4v1715858000000!5m2!1sen!2sin" 
          width="100%" 
          height="100%" 
          style={{ border: 0 }} 
          allowFullScreen 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </section>
    </div>
  );
};

export default Contact;
