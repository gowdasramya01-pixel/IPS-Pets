
import React, { useState, useRef } from 'react';
import { useCMS } from '../App';
import { 
  Save, 
  Plus, 
  Trash2, 
  Layout, 
  Type, 
  Palette, 
  Image as ImageIcon,
  CheckCircle2,
  Settings,
  Dog,
  FileText,
  Upload,
  Link as LinkIcon
} from 'lucide-react';
import { Breed, BlogPost } from '../types';

const Admin: React.FC = () => {
  const { state, setState } = useCMS();
  const [activeTab, setActiveTab] = useState<'content' | 'breeds' | 'blog' | 'theme' | 'seo'>('content');
  const [saveStatus, setSaveStatus] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const heroFileInputRef = useRef<HTMLInputElement>(null);
  const [editingBreedId, setEditingBreedId] = useState<string | null>(null);

  const handleSave = () => {
    setSaveStatus(true);
    setTimeout(() => setSaveStatus(false), 2000);
  };

  const updateContent = (key: keyof typeof state.content, value: string) => {
    setState(prev => ({
      ...prev,
      content: { ...prev.content, [key]: value }
    }));
  };

  const updateTheme = (key: keyof typeof state.theme, value: string) => {
    setState(prev => ({
      ...prev,
      theme: { ...prev.theme, [key]: value }
    }));
  };

  const updateSEO = (key: keyof typeof state.seo, value: string) => {
    setState(prev => ({
      ...prev,
      seo: { ...prev.seo, [key]: value }
    }));
  };

  const addBreed = () => {
    const newBreed: Breed = {
      id: Date.now().toString(),
      name: 'New Breed',
      description: 'Breed description goes here.',
      image: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&q=80&w=800'
    };
    setState(prev => ({ ...prev, breeds: [newBreed, ...prev.breeds] }));
  };

  const deleteBreed = (id: string) => {
    setState(prev => ({ ...prev, breeds: prev.breeds.filter(b => b.id !== id) }));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, breedId: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        const updated = state.breeds.map(b => b.id === breedId ? { ...b, image: base64String } : b);
        setState(prev => ({ ...prev, breeds: updated }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleHeroUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        updateContent('heroImage', base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileUpload = (breedId: string) => {
    setEditingBreedId(breedId);
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const triggerHeroUpload = () => {
    if (heroFileInputRef.current) {
      heroFileInputRef.current.click();
    }
  };

  const addPost = () => {
    const newPost: BlogPost = {
      id: Date.now().toString(),
      title: 'New Blog Post',
      content: 'Start writing your post...',
      date: new Date().toISOString().split('T')[0],
      image: 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?auto=format&fit=crop&q=80&w=800'
    };
    setState(prev => ({ ...prev, posts: [newPost, ...prev.posts] }));
  };

  return (
    <div className="min-h-screen bg-slate-100 pb-20">
      {/* Hidden Global File Inputs */}
      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        accept="image/*"
        onChange={(e) => editingBreedId && handleFileUpload(e, editingBreedId)}
      />
      <input 
        type="file" 
        ref={heroFileInputRef} 
        className="hidden" 
        accept="image/*"
        onChange={handleHeroUpload}
      />

      {/* Header */}
      <div className="bg-slate-900 text-white py-6">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Settings className="w-8 h-8 text-amber-500" />
            <h1 className="text-2xl font-bold">IPS Pets CMS</h1>
          </div>
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 px-6 py-2.5 rounded-xl font-bold transition-all shadow-lg"
          >
            {saveStatus ? <CheckCircle2 className="w-5 h-5" /> : <Save className="w-5 h-5" />}
            {saveStatus ? 'Changes Saved' : 'Save All Changes'}
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-8 flex flex-col lg:flex-row gap-8">
        {/* Sidebar Nav */}
        <div className="lg:w-64 space-y-2">
          {[
            { id: 'content', label: 'Main Content', icon: <Type className="w-5 h-5" /> },
            { id: 'breeds', label: 'Breed Management', icon: <Dog className="w-5 h-5" /> },
            { id: 'blog', label: 'Blog Posts', icon: <FileText className="w-5 h-5" /> },
            { id: 'theme', label: 'Theme Styling', icon: <Palette className="w-5 h-5" /> },
            { id: 'seo', label: 'SEO Settings', icon: <Layout className="w-5 h-5" /> },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                activeTab === item.id ? 'bg-amber-500 text-white shadow-lg' : 'bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </div>

        {/* Editor Area */}
        <div className="flex-grow bg-white rounded-3xl p-8 shadow-sm">
          {activeTab === 'content' && (
            <div className="space-y-8">
              <h2 className="text-xl font-bold border-b pb-4">Edit Site Content</h2>
              
              {/* Hero Image Section */}
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                <label className="block text-sm font-bold text-slate-700 mb-4 uppercase tracking-wide">Hero Background Image</label>
                <div className="flex flex-col md:flex-row gap-6 items-start">
                  <div className="relative w-full md:w-64 aspect-video flex-shrink-0 group overflow-hidden rounded-xl shadow-md">
                    <img 
                      src={state.content.heroImage} 
                      className="w-full h-full object-cover transition-transform group-hover:scale-105" 
                      alt="Hero Preview" 
                    />
                    <button 
                      onClick={triggerHeroUpload}
                      className="absolute inset-0 bg-black/40 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity flex-col gap-1"
                    >
                      <Upload className="w-6 h-6" />
                      <span className="text-[10px] font-bold uppercase">Upload Image</span>
                    </button>
                  </div>
                  <div className="flex-grow w-full">
                    <label className="text-xs font-bold text-slate-500 uppercase mb-2 block">Image URL</label>
                    <div className="relative">
                      <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="Paste an image URL here..."
                        className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                        value={state.content.heroImage.startsWith('data:') ? '' : state.content.heroImage}
                        onChange={(e) => updateContent('heroImage', e.target.value)}
                      />
                    </div>
                    <p className="mt-3 text-xs text-slate-400 italic">Recommended size: 1920x1080px. You can upload a file or use a direct URL.</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Hero Title</label>
                <input 
                  type="text" 
                  className="w-full p-4 bg-slate-50 rounded-xl border-slate-200 outline-none focus:ring-2 focus:ring-amber-500 font-bold text-lg"
                  value={state.content.heroTitle}
                  onChange={(e) => updateContent('heroTitle', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Hero Subtitle</label>
                <textarea 
                  rows={3}
                  className="w-full p-4 bg-slate-50 rounded-xl border-slate-200 outline-none focus:ring-2 focus:ring-amber-500"
                  value={state.content.heroSubtitle}
                  onChange={(e) => updateContent('heroSubtitle', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">About IPS Pets</label>
                <textarea 
                  rows={6}
                  className="w-full p-4 bg-slate-50 rounded-xl border-slate-200 outline-none focus:ring-2 focus:ring-amber-500"
                  value={state.content.aboutText}
                  onChange={(e) => updateContent('aboutText', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Contact Phone</label>
                <input 
                  type="text" 
                  className="w-full p-4 bg-slate-50 rounded-xl border-slate-200 outline-none focus:ring-2 focus:ring-amber-500"
                  value={state.content.contactPhone}
                  onChange={(e) => updateContent('contactPhone', e.target.value)}
                />
              </div>
            </div>
          )}

          {activeTab === 'breeds' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Manage Breeds</h2>
                <button 
                  onClick={addBreed}
                  className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg font-bold hover:bg-slate-700 transition-colors"
                >
                  <Plus className="w-5 h-5" /> Add New Breed
                </button>
              </div>
              <div className="grid grid-cols-1 gap-6">
                {state.breeds.map((breed) => (
                  <div key={breed.id} className="p-6 bg-slate-50 rounded-2xl border flex flex-col md:flex-row gap-6 group hover:border-amber-200 transition-colors">
                    <div className="relative w-full md:w-32 h-32 flex-shrink-0">
                      <img src={breed.image} className="w-full h-full object-cover rounded-xl shadow-inner border border-slate-200" alt={breed.name} />
                      <button 
                        onClick={() => triggerFileUpload(breed.id)}
                        className="absolute inset-0 bg-black/40 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-xl transition-opacity flex-col gap-1"
                      >
                        <Upload className="w-6 h-6" />
                        <span className="text-[10px] font-bold uppercase">Change</span>
                      </button>
                    </div>
                    
                    <div className="flex-grow space-y-4">
                      <div className="flex flex-col md:flex-row md:items-center gap-4">
                        <div className="flex-grow">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Breed Name</label>
                          <input 
                            className="font-bold bg-white px-3 py-2 border border-slate-200 rounded-lg w-full outline-none focus:ring-2 focus:ring-amber-500" 
                            value={breed.name} 
                            onChange={(e) => {
                              const updated = state.breeds.map(b => b.id === breed.id ? { ...b, name: e.target.value } : b);
                              setState(prev => ({ ...prev, breeds: updated }));
                            }}
                          />
                        </div>
                        <div className="md:w-64">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Image URL (Optional)</label>
                          <div className="relative">
                            <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <input 
                              placeholder="Paste URL here..."
                              className="bg-white pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg w-full outline-none focus:ring-2 focus:ring-amber-500" 
                              value={breed.image.startsWith('data:') ? '' : breed.image} 
                              onChange={(e) => {
                                const updated = state.breeds.map(b => b.id === breed.id ? { ...b, image: e.target.value } : b);
                                setState(prev => ({ ...prev, breeds: updated }));
                              }}
                            />
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Description</label>
                        <textarea 
                          className="w-full bg-white px-3 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                          rows={2}
                          value={breed.description}
                          onChange={(e) => {
                            const updated = state.breeds.map(b => b.id === breed.id ? { ...b, description: e.target.value } : b);
                            setState(prev => ({ ...prev, breeds: updated }));
                          }}
                        />
                      </div>
                    </div>

                    <div className="flex items-start">
                      <button 
                        onClick={() => deleteBreed(breed.id)}
                        className="text-red-500 hover:bg-red-50 p-3 rounded-xl border border-transparent hover:border-red-100 transition-all"
                        title="Delete Breed"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'theme' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold border-b pb-4">Visual Branding</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-sm font-bold mb-2">Primary Brand Color</label>
                  <div className="flex gap-4">
                    <input 
                      type="color" 
                      className="w-12 h-12 rounded-lg cursor-pointer"
                      value={state.theme.primaryColor}
                      onChange={(e) => updateTheme('primaryColor', e.target.value)}
                    />
                    <input 
                      type="text" 
                      className="flex-grow p-3 bg-slate-50 rounded-lg font-mono text-sm"
                      value={state.theme.primaryColor}
                      onChange={(e) => updateTheme('primaryColor', e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold mb-2">Secondary Color</label>
                  <div className="flex gap-4">
                    <input 
                      type="color" 
                      className="w-12 h-12 rounded-lg cursor-pointer"
                      value={state.theme.secondaryColor}
                      onChange={(e) => updateTheme('secondaryColor', e.target.value)}
                    />
                    <input 
                      type="text" 
                      className="flex-grow p-3 bg-slate-50 rounded-lg font-mono text-sm"
                      value={state.theme.secondaryColor}
                      onChange={(e) => updateTheme('secondaryColor', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'seo' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold border-b pb-4">SEO & Metadata</h2>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Meta Title Tag</label>
                <input 
                  type="text" 
                  className="w-full p-4 bg-slate-50 rounded-xl border-slate-200 outline-none focus:ring-2 focus:ring-amber-500"
                  value={state.seo.metaTitle}
                  onChange={(e) => updateSEO('metaTitle', e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Meta Description</label>
                <textarea 
                  rows={4}
                  className="w-full p-4 bg-slate-50 rounded-xl border-slate-200 outline-none focus:ring-2 focus:ring-amber-500"
                  value={state.seo.metaDescription}
                  onChange={(e) => updateSEO('metaDescription', e.target.value)}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admin;
