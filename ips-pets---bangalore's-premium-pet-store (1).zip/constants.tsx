
import React from 'react';
import { CMSState } from './types';
import { Dog } from 'lucide-react';

export const INITIAL_STATE: CMSState = {
  breeds: [
    { id: '1', name: 'Labrador Retriever', description: 'Friendly, active, and outgoing. Great family pets.', image: 'https://images.unsplash.com/photo-1591769225440-811ad7d6eca3?auto=format&fit=crop&q=80&w=800' },
    { id: '2', name: 'Golden Retriever', description: 'Intelligent, kind, and trustworthy. The ultimate companion.', image: 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&q=80&w=800' },
    { id: '3', name: 'German Shepherd', description: 'Confident, courageous, and smart. Excellent protectors.', image: 'https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?auto=format&fit=crop&q=80&w=800' },
    { id: '4', name: 'Rottweiler', description: 'Loyal, loving, and a confident guardian.', image: 'https://images.unsplash.com/photo-1567752881298-894bb81f9379?auto=format&fit=crop&q=80&w=800' },
    { id: '5', name: 'Doberman', description: 'Alert, fearless, and incredibly loyal.', image: 'https://images.unsplash.com/photo-1553736026-ff14d1f8d222?auto=format&fit=crop&q=80&w=800' },
    { id: '6', name: 'Beagle', description: 'Merry, friendly, and curious hunters.', image: 'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?auto=format&fit=crop&q=80&w=800' },
    { id: '7', name: 'Pug', description: 'Charming, mischievous, and loving small dogs.', image: 'https://images.unsplash.com/photo-1517423440428-a5a00ad493e8?auto=format&fit=crop&q=80&w=800' },
    { id: '8', name: 'Shih Tzu', description: 'Affectionate, playful, and outgoing house pets.', image: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&q=80&w=800' },
    { id: '9', name: 'Chow Chow', description: 'Dignified, bright, and serious companions.', image: 'https://images.unsplash.com/photo-1591768793355-74d7c8360525?auto=format&fit=crop&q=80&w=800' },
    { id: '10', name: 'Siberian Husky', description: 'Loyal, mischievous, and outgoing.', image: 'https://images.unsplash.com/photo-1605568427561-4aa7594d2417?auto=format&fit=crop&q=80&w=800' },
    { id: '11', name: 'Dachshund', description: 'Spunky, curious, and friendly.', image: 'https://images.unsplash.com/photo-1514373941175-0a1410629b7a?auto=format&fit=crop&q=80&w=800' },
    { id: '12', name: 'Cocker Spaniel', description: 'Gentle, smart, and happy breed.', image: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&q=80&w=800' },
    { id: '13', name: 'Great Dane', description: 'Friendly, patient, and dependable giants.', image: 'https://images.unsplash.com/photo-1596492784531-6e6eb5ea9993?auto=format&fit=crop&q=80&w=800' },
    { id: '14', name: 'Saint Bernard', description: 'Playful, charming, and inquisitive.', image: 'https://images.unsplash.com/photo-1587559070757-f72a388edbba?auto=format&fit=crop&q=80&w=800' },
    { id: '15', name: 'Lhasa Apso', description: 'Confident, smart, and funny.', image: 'https://images.unsplash.com/photo-1510337550647-e83f8368d593?auto=format&fit=crop&q=80&w=800' },
    { id: '16', name: 'Boxer', description: 'Bright, fun-loving, and active.', image: 'https://images.unsplash.com/photo-1558322394-4d8813ceef8a?auto=format&fit=crop&q=80&w=800' },
    { id: '17', name: 'Poodle', description: 'Proud, active, and very smart.', image: 'https://images.unsplash.com/photo-1591768575198-88dac53fbd0a?auto=format&fit=crop&q=80&w=800' },
    { id: '18', name: 'French Mastiff', description: 'Courageous, loyal, and affectionate.', image: 'https://images.unsplash.com/photo-1628153344158-693081e74175?auto=format&fit=crop&q=80&w=800' },
    { id: '19', name: 'Axsire Terrier', description: 'Lively, friendly, and fearless.', image: 'https://images.unsplash.com/photo-1583512603805-3cc6b41f3edb?auto=format&fit=crop&q=80&w=800' },
    { id: '20', name: 'French Bulldog', description: 'Playful, smart, and adaptable.', image: 'https://images.unsplash.com/photo-1583511655826-05700d52f4d9?auto=format&fit=crop&q=80&w=800' },
    { id: '21', name: 'Neopolitan Mastiff', description: 'Watchful, dignified, and loyal.', image: 'https://images.unsplash.com/photo-1605568427561-4aa7594d2417?auto=format&fit=crop&q=80&w=800' },
    { id: '22', name: 'Belgium Malinois', description: 'Confident, smart, and hardworking.', image: 'https://images.unsplash.com/photo-1615751072497-5f5169febe17?auto=format&fit=crop&q=80&w=800' },
    { id: '23', name: 'Chihuahua', description: 'Graceful, alert, and sassy.', image: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&q=80&w=800' },
    { id: '24', name: 'Cane Corso', description: 'Affectionate, intelligent, and majestic.', image: 'https://images.unsplash.com/photo-1530281700549-e82e7bf110d6?auto=format&fit=crop&q=80&w=800' },
    { id: '25', name: 'Dalmatian', description: 'Dignified, outgoing, and smart.', image: 'https://images.unsplash.com/photo-1534361960057-19889db9621e?auto=format&fit=crop&q=80&w=800' },
    { id: '26', name: 'Pitbull', description: 'Confident, smart, and good-natured.', image: 'https://images.unsplash.com/photo-1571873715537-a428d8a675ba?auto=format&fit=crop&q=80&w=800' },
    { id: '27', name: 'Persian Kitten', description: 'Quiet, sweet, and affectionate.', image: 'https://images.unsplash.com/photo-1556012018-501537300870?auto=format&fit=crop&q=80&w=800' },
    { id: '28', name: 'Mudhol Hound', description: 'Brave, sharp, and loyal Indian breed.', image: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&q=80&w=800' },
  ],
  posts: [
    { id: '1', title: 'Top 5 Tips for Puppy Training', content: 'Consistency is key when it comes to training your new furry friend...', date: '2024-05-15', image: 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?auto=format&fit=crop&q=80&w=800' },
    { id: '2', title: 'Essential Grooming Routine', content: 'Regular brushing and bathing keeps your pet’s coat healthy and shiny...', date: '2024-05-10', image: 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?auto=format&fit=crop&q=80&w=800' }
  ],
  testimonials: [
    { id: '1', name: 'Rahul Sharma', text: 'I found my perfect Golden Retriever here. The process was transparent and smooth.', rating: 5 },
    { id: '2', name: 'Priya Verma', text: 'Exceptional service! They really care about the health of the puppies.', rating: 5 }
  ],
  theme: {
    primaryColor: '#f59e0b', // amber-500
    secondaryColor: '#1e293b', // slate-800
    fontFamily: 'Montserrat',
    borderRadius: '0.75rem'
  },
  content: {
    heroTitle: 'Find Your Perfect Companion At IPS Pets',
    heroSubtitle: 'Bangalore\'s Most Trusted Destination for Quality Breeds at Affordable Prices.',
    aboutText: 'IPS Pets is a premier pet agency in Bangalore dedicated to connecting families with healthy, happy, and well-bred puppies. With years of experience and a passion for animals, we ensure that every pet finds its forever home with care and integrity.',
    contactPhone: '9036941311',
    heroImage: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&q=80&w=2000'
  },
  seo: {
    metaTitle: 'IPS Pets Bangalore - Quality Puppies for Sale',
    metaDescription: 'Looking for a puppy in Bangalore? IPS Pets offers high-quality, healthy dog breeds at affordable prices. Trusted breeders with verified health certificates.'
  }
};
