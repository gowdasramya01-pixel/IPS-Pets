
export interface Breed {
  id: string;
  name: string;
  description: string;
  image: string;
}

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  date: string;
  image: string;
}

export interface Testimonial {
  id: string;
  name: string;
  text: string;
  rating: number;
}

export interface ThemeConfig {
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;
  borderRadius: string;
}

export interface SiteContent {
  heroTitle: string;
  heroSubtitle: string;
  aboutText: string;
  contactPhone: string;
  heroImage: string;
}

export interface CMSState {
  breeds: Breed[];
  posts: BlogPost[];
  testimonials: Testimonial[];
  theme: ThemeConfig;
  content: SiteContent;
  seo: {
    metaTitle: string;
    metaDescription: string;
  };
}
