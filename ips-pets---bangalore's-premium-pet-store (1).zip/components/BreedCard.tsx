
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { MessageCircle, Info } from 'lucide-react';
import { Breed } from '../types';
import { useCMS } from '../App';

interface BreedCardProps {
  breed: Breed;
}

const BreedCard: React.FC<BreedCardProps> = ({ breed }) => {
  const { state } = useCMS();
  const whatsappUrl = `https://wa.me/91${state.content.contactPhone}?text=Hi, I am interested in the ${breed.name} puppy.`;

  return (
    <motion.div 
      whileHover={{ y: -8 }}
      className="bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 border border-slate-100 group"
    >
      <div className="relative aspect-square overflow-hidden">
        <img 
          src={breed.image} 
          alt={breed.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-widest text-slate-900 shadow-sm">
            Verified Healthy
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-slate-900 mb-2">{breed.name}</h3>
        <p className="text-slate-500 text-sm mb-6 line-clamp-2 leading-relaxed">
          {breed.description}
        </p>
        
        <div className="flex gap-2">
          <a 
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-grow flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-xl transition-all text-sm shadow-lg shadow-green-500/10"
          >
            <MessageCircle className="w-4 h-4" /> Inquiry
          </a>
          <Link 
            to="/contact"
            className="w-12 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-all"
          >
            <Info className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
};

export default BreedCard;
