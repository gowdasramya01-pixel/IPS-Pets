
import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  Dog, 
  Menu, 
  X, 
  Phone, 
  MessageCircle, 
  Settings, 
  Home as HomeIcon, 
  Info, 
  LayoutList, 
  BookOpen, 
  Star, 
  Mail,
  Instagram,
  Facebook
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Types & Constants
import { CMSState } from './types';
import { INITIAL_STATE } from './constants';

// Pages
import Home from './pages/Home';
import About from './pages/About';
import Breeds from './pages/Breeds';
import Blog from './pages/Blog';
import Testimonials from './pages/Testimonials';
import Contact from './pages/Contact';
import Admin from './pages/Admin';

// Context
const CMSContext = createContext<{
  state: CMSState;
  setState: React.Dispatch<React.SetStateAction<CMSState>>;
}>({
  state: INITIAL_STATE,
  setState: () => {},
});

export const useCMS = () => useContext(CMSContext);

// Layout Components
const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { state } = useCMS();

  const navLinks = [
    { name: 'Home', path: '/', icon: <HomeIcon className="w-4 h-4" /> },
    { name: 'About', path: '/about', icon: <Info className="w-4 h-4" /> },
    { name: 'Breeds', path: '/breeds', icon: <LayoutList className="w-4 h-4" /> },
    { name: 'Blog', path: '/blog', icon: <BookOpen className="w-4 h-4" /> },
    { name: 'Testimonials', path: '/testimonials', icon: <Star className="w-4 h-4" /> },
    { name: 'Contact', path: '/contact', icon: <Phone className="w-4 h-4" /> },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 glass shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="bg-amber-500 p-2 rounded-full transition-transform group-hover:rotate-12">
              <Dog className="text-white w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-slate-800 leading-none">IPS PETS</span>
              <span className="text-[10px] text-slate-500 font-semibold tracking-widest uppercase">Bangalore</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${
                  location.pathname === link.path ? 'text-amber-500' : 'text-slate-600 hover:text-amber-500'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Link to="/admin" className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-500">
              <Settings className="w-5 h-5" />
            </Link>
          </div>

          {/* Mobile Toggle */}
          <div className="md:hidden flex items-center gap-4">
            <Link to="/admin" className="p-2 text-slate-500">
              <Settings className="w-5 h-5" />
            </Link>
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-700">
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t"
          >
            <div className="px-4 pt-2 pb-6 space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`flex items-center gap-3 px-3 py-4 text-base font-medium rounded-lg ${
                    location.pathname === link.path ? 'bg-amber-50 text-amber-600' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {link.icon}
                  {link.name}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Footer = () => {
  const { state } = useCMS();
  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-amber-500 p-2 rounded-full">
                <Dog className="text-white w-5 h-5" />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">IPS PETS</span>
            </div>
            <p className="max-w-md text-slate-400 leading-relaxed mb-6">
              {state.content.aboutText}
            </p>
            <div className="flex gap-4">
              <a href="https://instagram.com" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-500 transition-colors">
                <Instagram className="w-5 h-5 text-white" />
              </a>
              <a href="https://facebook.com" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-500 transition-colors">
                <Facebook className="w-5 h-5 text-white" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><Link to="/breeds" className="hover:text-amber-500 transition-colors">Available Breeds</Link></li>
              <li><Link to="/about" className="hover:text-amber-500 transition-colors">About Us</Link></li>
              <li><Link to="/blog" className="hover:text-amber-500 transition-colors">Pet Care Blog</Link></li>
              <li><Link to="/contact" className="hover:text-amber-500 transition-colors">Contact Support</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Contact Info</h4>
            <div className="space-y-4">
              <a href={`tel:${state.content.contactPhone}`} className="flex items-center gap-3 group">
                <Phone className="w-5 h-5 text-amber-500 group-hover:scale-110 transition-transform" />
                <span className="text-white font-bold text-lg">{state.content.contactPhone}</span>
              </a>
              <p className="text-sm">Bangalore, Karnataka, India</p>
              <p className="text-xs text-slate-500 mt-4 uppercase tracking-widest">Available 24/7 for Inquiries</p>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-slate-800 text-center text-sm text-slate-500">
          <p>© {new Date().getFullYear()} IPS Pets Bangalore. Quality Pets For Sale. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

const FloatingContact = () => {
  const { state } = useCMS();
  const whatsappUrl = `https://wa.me/91${state.content.contactPhone}`;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3">
      <motion.a
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        href={`tel:${state.content.contactPhone}`}
        className="bg-amber-500 text-white p-4 rounded-full shadow-2xl flex items-center justify-center"
      >
        <Phone className="w-6 h-6" />
      </motion.a>
      <motion.a
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="bg-green-500 text-white p-4 rounded-full shadow-2xl flex items-center justify-center"
      >
        <MessageCircle className="w-6 h-6" />
      </motion.a>
    </div>
  );
};

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  const [state, setState] = useState<CMSState>(() => {
    const saved = localStorage.getItem('ips_pets_cms_state');
    return saved ? JSON.parse(saved) : INITIAL_STATE;
  });

  useEffect(() => {
    localStorage.setItem('ips_pets_cms_state', JSON.stringify(state));
    document.title = state.seo.metaTitle;
  }, [state]);

  return (
    <CMSContext.Provider value={{ state, setState }}>
      <Router>
        <ScrollToTop />
        <div 
          className="min-h-screen flex flex-col" 
          style={{ 
            fontFamily: state.theme.fontFamily,
          }}
        >
          <Navbar />
          <main className="flex-grow pt-20">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/breeds" element={<Breeds />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/testimonials" element={<Testimonials />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/admin" element={<Admin />} />
            </Routes>
          </main>
          <Footer />
          <FloatingContact />
        </div>
      </Router>
    </CMSContext.Provider>
  );
};

export default App;
